# [Assignment 2]

## Description
To gain experience with the different data types in Python through declaring and using them

## Author
Zander Santos

## Assignment
Assignment 2 - Introduction to Python: Declaring and Using Variables

## Discuss in your own words the importance of following predefined standards in software development.
The use of predifined standards in software developement is important because it allows for a well-organized and readable code. This is especially important when working with a team because it allows the team of software developers to be more structured, well organized and consistent which will lead to more efficient teamwork and collaboration.
## Discuss in your own words ways in which a software developer can employ ethical habits when writing code.
A way for a software developer to employ ethicical habits when wrting code is through the use of coding standards. Making sure your team is on the same page can be an employment of ethical habits as it allows inclusivity. This can also reduce the act of stealing others code from online sources.
## Describe the contents of the file(s) in this repository. Note: students may wish to revisit this at or near the end of the assignment.
The content of the files in this repository is about the declaration, updating and use of the different data types (Int, Float, Str, Bool) and more complex data types (Dict, List, Tuple and Sets) in Python 